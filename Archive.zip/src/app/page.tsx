"use client";

import React, { useMemo, useState, useRef } from "react";
import { motion } from "framer-motion";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Info, AlertTriangle, ListChecks } from "lucide-react";
// add with your other imports
import { setExternalSpellChecker, getExternalSpellChecker } from "@/lib/spell/bridge";
// (optional) grammar
// import { createLanguageToolChecker } from "@/lib/grammar/languagetool-client";

/**
 * CBM Writing & Spelling – TypeScript Web Tool (with dictionary packs + rule flags)
 *
 * Features:
 *  - Dictionary packs (demo bundles + custom lexicon) for WSC spell-checking
 *  - Automated CWS scoring with rule-based checks (capitalization, terminals)
 *  - Infraction flagging (definite vs possible) to speed teacher review
 *  - Spelling CLS scoring (unchanged), per-word breakdown and totals
 *
 * Notes (aligned to Wright, 1992; McMaster & Espin, 2007; Wright, 2013):
 *  - TWW: count words (misspellings included), exclude numerals
 *  - WSC: spelled-correct-in-isolation via dictionary packs + custom lexicon
 *  - CWS: adjacent unit pairs across words & essential punctuation; commas excluded; initial valid word yields 1
 *  - Terminal punctuation expected for sentences; capitalization expected after terminal
 */

// ———————————— Types & Constants ————————————

type UnitType = "word" | "numeral" | "comma" | "essentialPunct" | "other";

interface Token {
  raw: string;
  type: UnitType;
  idx: number; // global index in token stream
}

interface WordOverride { csw?: boolean }
interface PairOverride { cws?: boolean }

interface Infraction {
  kind: "definite" | "possible";
  tag: string; // e.g., SPELLING, CAPITALIZATION, TERMINAL, PAIR
  msg: string;
  at: number | string; // token idx or pair key
}

const WORD_RE = /^[A-Za-z]+(?:[-''][A-Za-z]+)*$/;
const NUMERAL_RE = /^\d+(?:[\.,]\d+)*/;
const ESSENTIAL_PUNCT = new Set([".", "?", "!", ";", ":", "—", "–", "(", ")", '"', "'", "\u201C", "\u201D", "\u2018", "\u2019"]);

// ———————————— Demo Dictionary Packs ————————————
// Tiny placeholder packs; in production, load larger dictionaries or WASM spellcheckers (Hunspell, etc.)
const PACKS: Record<string, string[]> = {
  "us-k2": [
    "i","a","and","the","was","it","is","in","to","we","you","he","she","they","see","like","go","went","have","had",
    "dog","cat","tree","trees","house","boat","water","ocean","day","night","because"
  ],
  "us-k5": [
    "because","friend","before","after","first","next","then","finally","forest","terrible","nobody","could","would","should",
    "drink","fruit","gather","firewood","build","built","fix","spare","time","warm","dark"
  ],
  general: [
    "the","of","and","to","in","for","on","with","as","by","from","this","that","is","are","was","were","be","been","have","has","had",
    "like","people","student","students","school","story","write","writing","sequence","correct","letter","letters","because","friend",
    "talk","forest","terrible","nobody","could","would","drink","ocean","house","trees"
  ]
};

function buildLexicon(selected: string[], userLex: string): Set<string> {
  const set = new Set<string>();
  selected.forEach((p) => PACKS[p]?.forEach((w) => set.add(w.toLowerCase())));
  userLex
    .split(/;|,|\s+/)
    .map((w) => w.trim().toLowerCase())
    .filter(Boolean)
    .forEach((w) => set.add(w));
  return set;
}

// ———————————— Tokenization ————————————

function tokenize(text: string): Token[] {
  const tokens: Token[] = [];
  const regex = /[A-Za-z]+(?:[-''][A-Za-z]+)*|[\.!\?;:\u2014\u2013\-\(\)"'\u201C\u201D\u2018\u2019]|,|\d+(?:[\.,]\d+)*/g;
  let m: RegExpExecArray | null;
  while ((m = regex.exec(text)) !== null) {
    const raw = m[0];
    const type: UnitType =
      NUMERAL_RE.test(raw) ? "numeral" :
      raw === "," ? "comma" :
      WORD_RE.test(raw) ? "word" :
      ESSENTIAL_PUNCT.has(raw) ? "essentialPunct" :
      /[\.!\?;:]/.test(raw) ? "essentialPunct" :
      "other";
    tokens.push({ raw, type, idx: tokens.length });
  }
  return tokens;
}

function sentenceBoundaries(text: string): { startIdx: number; endIdx: number; raw: string }[] {
  const parts = text.replace(/\n+/g, " ").split(/(?<=[\.!\?])\s+/).map((s) => s.trim()).filter(Boolean);
  const res: { startIdx: number; endIdx: number; raw: string }[] = [];
  let cursor = 0;
  parts.forEach((s) => {
    const start = text.indexOf(s, cursor);
    const end = start + s.length - 1;
    res.push({ startIdx: start, endIdx: end, raw: s });
    cursor = end + 1;
  });
  return res;
}

// ———————————— Spelling: Correct Letter Sequences (CLS) ————————————

function clsForWord(target: string, attempt: string): { cls: number; max: number; correctWhole: boolean } {
  const t = target.trim();
  const a = attempt.trim();
  const max = Math.max(t.length + 1, 1);
  let cls = 0;
  if (a[0] && a[0].toLowerCase() === t[0]?.toLowerCase()) cls++;
  for (let i = 0; i < t.length - 1; i++) {
    if (a[i] && a[i + 1] && a[i].toLowerCase() === t[i].toLowerCase() && a[i + 1].toLowerCase() === t[i + 1].toLowerCase()) cls++;
  }
  if (a[t.length - 1] && a[t.length - 1].toLowerCase() === t[t.length - 1]?.toLowerCase()) cls++;
  const correctWhole = a.toLowerCase() === t.toLowerCase();
  return { cls, max, correctWhole };
}

// ———————————— Writing: Spellcheck + CWS + Infractions ————————————

function computeTWW(tokens: Token[]): number {
  return tokens.filter((t) => t.type === "word").length;
}

function computeWSC(
  tokens: Token[],
  overrides: Record<number, WordOverride>,
  lexicon: Set<string>,
  infractions: Infraction[]
): number {
  let count = 0;
  tokens.forEach((t) => {
    if (t.type !== "word") return;
    const ok = overrides[t.idx]?.csw ?? isWordLikelyCorrect(t.raw, lexicon);
    if (!ok) infractions.push({ kind: "definite", tag: "SPELLING", msg: `Possible misspelling: "${t.raw}"`, at: t.idx });
    if (ok) count += 1;
  });
  return count;
}

function computeCWS(
  tokens: Token[],
  overrides: Record<string, PairOverride | WordOverride>,
  lexicon: Set<string>,
  infractions: Infraction[]
): number {
  const stream = tokens.filter((t) => t.type !== "comma" && t.type !== "other");
  const isValidWord = (t: Token) => t.type === "word" && ((overrides[t.idx as number] as WordOverride)?.csw ?? isWordLikelyCorrect(t.raw, lexicon));
  const isPunct = (t: Token) => t.type === "essentialPunct";
  const isTerminal = (s: string) => s === "." || s === "?" || s === "!";

  let cws = 0;
  if (stream[0]) {
    if (isValidWord(stream[0])) cws += 1;
    else infractions.push({ kind: "definite", tag: "PAIR", msg: "Initial word not valid for CWS (spelling)", at: stream[0].idx });
  }

  for (let i = 0; i < stream.length - 1; i++) {
    const a = stream[i];
    const b = stream[i + 1];
    const pairKey = `${a.idx}-${b.idx}`;
    const manual = (overrides[pairKey] as PairOverride | undefined)?.cws;
    if (manual !== undefined) {
      if (manual) cws += 1;
      else infractions.push({ kind: "possible", tag: "PAIR", msg: `Manual override: NOT CWS at ${a.raw} ^ ${b.raw}`, at: pairKey });
      continue;
    }

    if (isValidWord(a) && isValidWord(b)) {
      cws += 1;
    } else if (isValidWord(a) && isPunct(b)) {
      cws += 1;
      if (!isTerminal(b.raw) && b.raw !== ";" && b.raw !== ":") {
        infractions.push({ kind: "possible", tag: "PUNCT", msg: `Non-terminal punctuation in CWS: "${b.raw}"`, at: pairKey });
      }
    } else if (isPunct(a) && isValidWord(b)) {
      if (isTerminal(a.raw)) {
        if (/^[A-Z]/.test(b.raw)) { cws += 1; }
        else { infractions.push({ kind: "definite", tag: "CAPITALIZATION", msg: "Expected capital after sentence-ending punctuation", at: pairKey }); }
      } else {
        cws += 1; // lenient after non-terminal/parenthetical/quotes
      }
    } else {
      infractions.push({ kind: "possible", tag: "PAIR", msg: `Invalid adjacency: ${a.raw} ^ ${b.raw}`, at: pairKey });
    }
  }

  // Sentence-level flags
  const plain = tokens.map((t) => t.raw).join(" ");
  const sentences = sentenceBoundaries(plain);
  if (sentences.length > 0) {
    sentences.forEach((s) => {
      if (!/[\.!\?]$/.test(s.raw)) infractions.push({ kind: "possible", tag: "TERMINAL", msg: "Sentence may be missing terminal punctuation", at: s.raw.slice(0, 20) + "…" });
      const words = s.raw.split(/\s+/).filter((w) => WORD_RE.test(w));
      if (words.length > 30) infractions.push({ kind: "possible", tag: "RUN_ON", msg: "Long sentence (>30 words) – possible run-on", at: s.raw.slice(0, 20) + "…" });
      const firstWord = words[0];
      if (firstWord && !/^[A-Z]/.test(firstWord)) infractions.push({ kind: "definite", tag: "CAPITALIZATION", msg: "Sentence should start with a capital letter", at: firstWord });
    });
  }

  return cws;
}

// ———————————— UI Components ————————————

function SentenceList({ text }: { text: string }) {
  const sentences = useMemo(
    () => text.replace(/\n+/g, " ").split(/(?<=[\.!\?])\s+/).map((s) => s.trim()).filter(Boolean),
    [text]
  );
  return (
    <ol className="list-decimal ml-6 text-sm space-y-1">
      {sentences.map((s, i) => (<li key={i}>{s}</li>))}
    </ol>
  );
}

function InfractionList({ items }: { items: Infraction[] }) {
  if (!items.length) return <div className="text-sm text-muted-foreground">No infractions flagged.</div>;
  return (
    <div className="space-y-2">
      {items.map((f, i) => (
        <div
          key={i}
          className={`text-sm p-2 rounded-xl border ${f.kind === "definite" ? "border-red-300 bg-red-50" : "border-amber-300 bg-amber-50"}`}
        >
          <div className="flex items-center gap-2">
            {f.kind === "definite" ? <AlertTriangle className="h-4 w-4" /> : <ListChecks className="h-4 w-4" />}
            <Badge variant={f.kind === "definite" ? "destructive" : "secondary"}>{f.tag}</Badge>
            <span>{f.msg}</span>
          </div>
        </div>
      ))}
    </div>
  );
}

function WritingScorer() {
  const [text, setText] = useState<string>(
    "It was dark. nobody could see the trees of the forest The Terrible Day\n\nI woud drink water from the ocean and I woud eat the fruit off of the trees Then I woud bilit a house out of trees and I woud gather firewood to stay warm I woud try and fix my boat in my spare time"
  );
  const [overrides, setOverrides] = useState<Record<string | number, WordOverride | PairOverride>>({});
  const [userLex, setUserLex] = useState<string>("ocean forest Terrible Day trees firewood bilit");
  const [packSel, setPackSel] = useState<string[]>(["us-k2", "us-k5", "general"]);
  const [showFlags, setShowFlags] = useState<boolean>(true);
  // state near top of WritingScorer()
  const [ltBusy, setLtBusy] = useState(false);
  const [ltIssues, setLtIssues] = useState<string[]>([]);
  const spellCache = useRef<Map<string, boolean>>(new Map());

  function isWordLikelyCorrect(word: string, userLexicon: Set<string>): boolean {
    if (!WORD_RE.test(word)) return false;
    const key = word.toLowerCase();
    const cached = spellCache.current.get(key);
    if (cached !== undefined) return cached;

    const sc = getExternalSpellChecker();
    let ok: boolean;
    if (sc) {
      ok = sc.isCorrect(word);
    } else {
      const base = word.replace(/['']/g, "'").toLowerCase();
      ok = userLexicon.has(base) || [base.replace(/(ing|ed|es|s)$/,''), base.replace(/(ly)$/,'')].some(s => s && userLexicon.has(s));
    }

    spellCache.current.set(key, ok);
    return ok;
  }

  const lexicon = useMemo(() => buildLexicon(packSel, userLex), [packSel, userLex]);
  const tokens = useMemo(() => tokenize(text), [text]);
  const stream = useMemo(() => tokens.filter((t) => t.type !== "comma" && t.type !== "other"), [tokens]);

  const tww = useMemo(() => computeTWW(tokens), [tokens]);
  
  const { wsc, cws, infractions } = useMemo(() => {
    const infractions: Infraction[] = [];
    const wsc = computeWSC(tokens, overrides as Record<number, WordOverride>, lexicon, infractions);
    const cws = computeCWS(tokens, overrides as Record<string, PairOverride | WordOverride>, lexicon, infractions);
    return { wsc, cws, infractions };
  }, [tokens, overrides, lexicon]);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Written Expression (TWW, WSC, CWS) – with Flags</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium">Paste student writing</label>
            <Textarea className="min-h-[160px] mt-1" value={text} onChange={(e) => setText(e.target.value)} />

            <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium">Dictionary packs</label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {Object.keys(PACKS).map((k) => (
                    <Button
                      key={k}
                      size="sm"
                      variant={packSel.includes(k) ? "default" : "outline"}
                      onClick={() =>
                        setPackSel((prev) => prev.includes(k) ? prev.filter((p) => p !== k) : [...prev, k])
                      }
                    >
                      {k}
                    </Button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-xs font-medium">Custom lexicon (semicolon/comma/space separated)</label>
                <Input className="mt-1" value={userLex} onChange={(e) => setUserLex(e.target.value)} />
              </div>
            </div>

            <div className="flex items-center gap-2 mt-3">
              <Checkbox id="flags" checked={showFlags} onCheckedChange={(v) => setShowFlags(!!v)} />
              <label htmlFor="flags" className="text-sm">Show infractions & suggestions</label>
              <Button className="ml-auto" variant="secondary" onClick={() => setOverrides({})}>Reset overrides</Button>
            </div>

            <div className="flex gap-2 mt-3">
              <Button variant="secondary" onClick={() => setOverrides({})}>Reset overrides</Button>
              <Button variant="ghost" onClick={() => setText("")}>Clear text</Button>

              <Button
                variant="outline"
                title="Loads /public/dicts/en_US.aff & en_US.dic and enables Hunspell"
                onClick={async () => {
                  try {
                    const { createHunspellSpellChecker } = await import("@/lib/spell/hunspell-adapter");
                    const sc = await createHunspellSpellChecker("/dicts/en_US.aff", "/dicts/en_US.dic");
                    setExternalSpellChecker(sc);
                  } catch (e) {
                    console.error(e);
                    alert("Hunspell load failed. Confirm /public/dicts/en_US.aff & en_US.dic and WASM loader wiring.");
                  }
                }}
              >
                Load Hunspell
              </Button>

              <Button
                variant="outline"
                disabled={ltBusy}
                onClick={async () => {
                  setLtBusy(true);
                  try {
                    const { createLanguageToolChecker } = await import("@/lib/grammar/languagetool-client");
                    const lt = createLanguageToolChecker("/api/languagetool");
                    const issues = await lt.check(text, "en-US");
                    const msgs = issues.slice(0, 12).map(i => `${i.category}: ${i.message}`);
                    setLtIssues(msgs);
                  } catch (e) {
                    console.error(e);
                    alert("LanguageTool check failed. Consider the /api proxy or a self-hosted instance.");
                  } finally {
                    setLtBusy(false);
                  }
                }}
              >
                {ltBusy ? "Checking…" : "Grammar check"}
              </Button>
            </div>
          </div>

          <div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-3 rounded-2xl bg-white shadow-sm">
                <div className="text-xs text-muted-foreground">Total Words Written</div>
                <div className="text-2xl font-semibold">{tww}</div>
                <div className="text-[10px] text-muted-foreground">numerals excluded</div>
              </div>
              <div className="p-3 rounded-2xl bg-white shadow-sm">
                <div className="text-xs text-muted-foreground">Words Spelled Correctly</div>
                <div className="text-2xl font-semibold">{wsc}</div>
                <div className="text-[10px] text-muted-foreground">dictionary + overrides</div>
              </div>
              <div className="p-3 rounded-2xl bg-white shadow-sm">
                <div className="text-xs text-muted-foreground">Correct Writing Sequences</div>
                <div className="text-2xl font-semibold">{cws}</div>
                <div className="text-[10px] text-muted-foreground">adjacent-unit pairs</div>
              </div>
            </div>

            <div className="mt-4 text-xs text-muted-foreground flex items-center gap-2">
              <Info className="h-4 w-4" /> Click a <strong>word</strong> to toggle WSC; click the <strong>caret</strong> between tokens to toggle CWS.
            </div>

            <div className="mt-3 flex flex-wrap gap-1 p-3 rounded-2xl bg-muted/40">
              {stream.map((tok, i) => {
                const next = stream[i + 1];
                const isWord = tok.type === "word";
                const okWord = isWord && ((overrides[tok.idx] as WordOverride)?.csw ?? isWordLikelyCorrect(tok.raw, lexicon));
                const pairKey = next ? `${tok.idx}-${next.idx}` : null;
                const manual = pairKey ? (overrides[pairKey] as PairOverride | undefined)?.cws : undefined;

                return (
                  <span key={tok.idx} className="flex items-center">
                    <button
                      className={`px-1 rounded hover:bg-muted transition ${isWord ? (okWord ? "ring-1 ring-green-500/40" : "ring-1 ring-red-500/40") : ""}`}
                      title={isWord ? (okWord ? "WSC: counted (click to mark incorrect)" : "WSC: not counted (click to mark correct)") : tok.type}
                      onClick={() => {
                        if (!isWord) return;
                        setOverrides((o) => ({ ...o, [tok.idx]: { ...(o[tok.idx] as WordOverride), csw: !(okWord) } }));
                      }}
                    >
                      {tok.raw}
                    </button>
                    {next && (
                      <button
                        className={`mx-1 text-xs rounded px-1 py-0.5 border ${manual === undefined ? "border-transparent" : manual ? "border-green-500" : "border-red-500"}`}
                        title={manual === undefined ? "Toggle this adjacent pair as a CWS override" : manual ? "Override: counts as CWS (click to flip)" : "Override: NOT a CWS (click to flip)"}
                        onClick={() => {
                          setOverrides((o) => ({ ...o, [pairKey!]: { cws: !(manual ?? true) } }));
                        }}
                      >
                        ^
                      </button>
                    )}
                  </span>
                );
              })}
            </div>

            {showFlags && (
              <div className="mt-4">
                <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4" /> Infractions & Suggestions
                </h4>
                <InfractionList items={infractions} />
              </div>
            )}

            {/* somewhere under your scoring cards (simple readout) */}
            {ltIssues.length > 0 && (
              <div className="mt-3 text-xs p-2 rounded-xl border border-amber-300 bg-amber-50">
                <div className="font-medium mb-1">Grammar suggestions (advisory):</div>
                <ul className="list-disc ml-5 space-y-0.5">
                  {ltIssues.map((m, i) => <li key={i}>{m}</li>)}
                </ul>
              </div>
            )}

            <details className="mt-4">
              <summary className="cursor-pointer text-sm font-medium">Sentence view</summary>
              <SentenceList text={text} />
            </details>
          </div>
        </div>

        <div className="mt-6 text-xs text-muted-foreground">
          <p className="font-medium">Scoring guidance</p>
          <ul className="list-disc ml-5 space-y-1">
            <li><strong>TWW</strong>: all words written; include misspellings; exclude numerals.</li>
            <li><strong>WSC</strong>: each correctly spelled word in isolation (override by clicking). Click 'Load Hunspell' to use a real dictionary/affix checker; otherwise, a custom-lexicon fallback is used.</li>
            <li><strong>CWS</strong>: adjacent units (words & essential punctuation). Commas excluded. Initial valid word counts 1. Capitalize after terminals.</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}

function SpellingScorer() {
  const [targets, setTargets] = useState<string>("because, friend, talk, forest, terrible");
  const [attempts, setAttempts] = useState<string>("becuse, frend, tack, forist, terribel");

  const targetList = useMemo(() => targets.split(/,|;|\n/).map((w) => w.trim()).filter(Boolean), [targets]);
  const attemptList = useMemo(() => attempts.split(/,|;|\n/).map((w) => w.trim()).filter(Boolean), [attempts]);

  const rows = useMemo(() => {
    const n = Math.max(targetList.length, attemptList.length);
    const r: { target: string; attempt: string; cls: number; max: number; correct: boolean }[] = [];
    for (let i = 0; i < n; i++) {
      const t = targetList[i] ?? "";
      const a = attemptList[i] ?? "";
      const { cls, max, correctWhole } = clsForWord(t, a);
      r.push({ target: t, attempt: a, cls, max, correct: correctWhole });
    }
    return r;
  }, [targetList, attemptList]);

  const totals = useMemo(() => rows.reduce((acc, r) => {
    acc.cls += r.cls; acc.max += r.max; if (r.correct) acc.wordsCorrect += 1; if (r.target) acc.wordsTotal += 1; return acc;
  }, { cls: 0, max: 0, wordsCorrect: 0, wordsTotal: 0 }), [rows]);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Spelling (Correct Letter Sequences)</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium">Target words (comma/semicolon/newline separated)</label>
            <Textarea className="min-h-[120px] mt-1" value={targets} onChange={(e) => setTargets(e.target.value)} />
          </div>
          <div>
            <label className="text-sm font-medium">Student attempts (aligned order)</label>
            <Textarea className="min-h-[120px] mt-1" value={attempts} onChange={(e) => setAttempts(e.target.value)} />
          </div>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left border-b">
                <th className="py-2 pr-4">#</th>
                <th className="py-2 pr-4">Target</th>
                <th className="py-2 pr-4">Attempt</th>
                <th className="py-2 pr-4">CLS</th>
                <th className="py-2 pr-4">Max</th>
                <th className="py-2 pr-4">Word Correct</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i} className="border-b last:border-0">
                  <td className="py-1 pr-4">{i + 1}</td>
                  <td className="py-1 pr-4 font-medium">{r.target}</td>
                  <td className="py-1 pr-4">{r.attempt}</td>
                  <td className="py-1 pr-4">{r.cls}</td>
                  <td className="py-1 pr-4">{r.max}</td>
                  <td className="py-1 pr-4">{r.correct ? "✓" : ""}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-3 grid grid-cols-3 gap-2 text-center">
          <div className="p-3 rounded-2xl bg-white shadow-sm">
            <div className="text-xs text-muted-foreground">Total CLS</div>
            <div className="text-2xl font-semibold">{totals.cls}</div>
          </div>
          <div className="p-3 rounded-2xl bg-white shadow-sm">
            <div className="text-xs text-muted-foreground">Max CLS</div>
            <div className="text-2xl font-semibold">{totals.max}</div>
          </div>
          <div className="p-3 rounded-2xl bg-white shadow-sm">
            <div className="text-xs text-muted-foreground">Words Correct</div>
            <div className="text-2xl font-semibold">{totals.wordsCorrect} / {totals.wordsTotal}</div>
          </div>
        </div>

        <div className="mt-4 text-xs text-muted-foreground">
          <ul className="list-disc ml-5 space-y-1">
            <li><strong>CLS</strong> counts boundary + adjacent letter pairs per target word (partial knowledge credit).</li>
            <li>Use aligned lists so attempt #i corresponds to target #i.</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}

export default function CBMApp(): JSX.Element {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <motion.h1 initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} className="text-2xl md:text-3xl font-bold">
          CBM Writing & Spelling – Web Tool (TS) + Dictionary Packs & Flags
        </motion.h1>

        <div className="mt-4">
          <Tabs defaultValue="writing">
            <TabsList>
              <TabsTrigger value="writing">Written Expression</TabsTrigger>
              <TabsTrigger value="spelling">Spelling</TabsTrigger>
            </TabsList>
            <TabsContent value="writing" className="mt-3">
              <WritingScorer />
            </TabsContent>
            <TabsContent value="spelling" className="mt-3">
              <SpellingScorer />
            </TabsContent>
          </Tabs>
        </div>

        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Implementation Notes</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="text-sm list-disc ml-5 space-y-1">
              <li><strong>Dictionary packs</strong>: demo packs included; swap in real dictionaries or WASM spellcheckers for production.</li>
              <li><strong>Capitalization & terminals</strong>: heuristic checks flag definite/possible issues for quick review.</li>
              <li><strong>Overrides</strong>: click words to toggle WSC; click carets to toggle CWS.</li>
              <li><strong>Extensibility</strong>: replace <code>isWordSpelledCorrect</code> with Hunspell/LanguageTool adapters; add POS-based rules if desired.</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

# Dictionary Files

Place Hunspell dictionary files here:

- `en_US.aff` - US English affix file
- `en_US.dic` - US English dictionary file

You can obtain these from:
- LibreOffice dictionaries
- SCOWL (Spell Checker Oriented Word Lists)
- Other Hunspell-compatible sources

The adapter will load these files when creating a Hunspell spell checker instance.
